telegram_token = '6483287271:AAGqq9lxq_JRh0rVE3lViJ9drWb25wWPMUE'
admin_chat_id = 743299567
user_chat_id = 743299567
video_path = '/mp4/'
audio_path = '/mp3/'
enable_ftp = 'false'
ftp_site = 'https://path.to.site/'
